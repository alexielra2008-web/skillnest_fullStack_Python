#Desafio:
datos = [
    {"nombre": "Carlos", "puntaje": 80},
    {"nombre": "María", "puntaje": 95},
    {"nombre": "Pedro", "puntaje": 70}
]

datos[2]["puntaje"] = 80

for separarDatos, ordenDatos in datos():
    print(separarDatos)
    for item in ordenDatos:
        print()
